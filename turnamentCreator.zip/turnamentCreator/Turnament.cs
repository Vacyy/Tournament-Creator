﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace turnamentCreator
{
    internal class Turnament
    {
        public int ID { get; set; }
        public List<Team> Teams = new List<Team>();
        public int TypeID;

        public Turnament(int id, List<Team> teams, int typeID)
        {
            this.ID = id;
            this.Teams = teams;
            this.TypeID = typeID;
        }
        public List<Match> Round1Genarator()
        {
            List<Match> Matches = new List<Match>();
            int i = 0;
            do
            {
                Matches.Add(new Match(i, Teams[i], Teams[15 - i]));
                i++;
            } while (i < 8);
            return Matches;
        }

    }
}
