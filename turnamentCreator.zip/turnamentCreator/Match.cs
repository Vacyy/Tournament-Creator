﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace turnamentCreator
{
    internal class Match
    {
        public int ID { get; set; }
        public Team Team1 { get; set; }
        public Team Team2 { get; set; }
        
        public bool? Result { get; set; } 
        public Match(int ID, Team team1, Team team2) 
        {
            this.ID = ID;
            this.Team1 = team1;
            this.Team2 = team2;
        }
    }
}
