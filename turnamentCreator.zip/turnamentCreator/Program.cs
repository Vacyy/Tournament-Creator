﻿namespace turnamentCreator
{
    internal class Program
    {
        static void Main(string[] args)
        {
            List<Team> teams = new List<Team>
{
                new Team(1, "Wilki Północy"),
                new Team(2, "Sokoły Wschodu"),
                new Team(3, "Orły Południa"),
                new Team(4, "Niedźwiedzie Zachodu"),
                new Team(5, "Lwy Pustyni"),
                new Team(6, "Smoki Górskie"),
                new Team(7, "Rekiny Oceanu"),
                new Team(8, "Pantery Dżungli"),
                new Team(9, "Kozły Górskie"),
                new Team(10, "Tygrysy Tajgi"),
                new Team(11, "Borsuki Bagien"),
                new Team(12, "Rysie Lasów"),
                new Team(13, "Sowy Mroku"),
                new Team(14, "Jastrzębie Wiatru"),
                new Team(15, "Węże Doliny"),
                new Team(16, "Lisice Łąk")
            };
            //foreach (var team in teams)
            //{
            //    Console.WriteLine();
            //}
            Turnament newSwiss = new Turnament(1, teams, 1);
            List<Match> MatchesList = newSwiss.Round1Genarator();
            foreach (var match in MatchesList)
            {
                Console.WriteLine($"Match {match.ID}: {match.Team1.Name} vs. {match.Team2.Name}");
            }
        }
    }
}